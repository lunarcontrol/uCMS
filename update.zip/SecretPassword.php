<?php
//Please Replace the password and username in the apprpriate slot!
//They are case sensititive and can be changed any time ;)
$Username = 'Admin';
//Password
$Password = 'Admin123';
//Only edit Admin and Admin123
//make sure not to remove the ' as well..

//If you are having trouble, create an help request here:
//                                                             https://github.com/DatRoyce/uCMS/issues
?>
