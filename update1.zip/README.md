# uCMS -Royce Whitaker

## Cool New Features

    * New Backend
    *Everything Is Responsive!!


# Release(s)
0.1.0 Pre-Alpha (January 15, 2015):
View it [Here!](https://github.com/DatRoyce/uCMS/releases/tag/0.1.0-Pre-Alpha)

# Setup

Simply Place ALL the files on your server and navigate to example.com/install.php

# To Be Done

* Update License
* Image/video Gallery
* Responsive Backend
* Optimize Custom Themes

# Know Issues

* Visit The Bug/Issue Tracker!
[Here!](https://github.com/DatRoyce/uCMS/issues)

# License

## The MIT License (MIT)

Copyright (c) 2015  Royce Whitaker

In addition to following, I ask that you do **NOT** remove/edit the code comments that say "Please Do Not Remove"**

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

